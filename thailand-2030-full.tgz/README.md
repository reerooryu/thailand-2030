# Thailand 2030

A quarterly-turn macroeconomic and political simulation. Design stage — no engine yet.

## Contents

| Path | What |
|---|---|
| `DESIGN.md` | Full design document. 16 sections: macro model, fiscal/monetary, political system, card schema, UI, build order. |
| `CALIBRATION.md` | What each dataset changed about the design. Read alongside DESIGN §3.4 and §6.3. |
| `MODEL.md` | First-pass estimation. **Read §1 first** — the panel validates, it does not calibrate. |
| `LITERATURE.md` | Fiscal multipliers by instrument, monetary transmission, the execution wedge. |
| `GAMELOOP.md` | **The turn state machine** — events, deferrals, dependencies, scoring. |
| `EVENTS.md` | **Blocking news events** and consequence chains. |
| `POLICIES.md` | **Seven real Thai policy cards** and what survives each coalition. |
| `POLITICS.md` | **Coalition formation and parliamentary support.** The prologue decision. |
| `PLAYABILITY.md` | **The realism/playability trade.** One config file, fully reversible. |
| `SUPPLY.md` | **Production function, Legacy mechanism, scenario test.** Read §3.2 — it needs a design decision. |
| `SIMULATION.md` | Full dynamic run, 125 quarters. No divergence, near-zero bias. |
| `BACKTEST.md` | One-step-ahead gate result. Which blocks pass, and why fitting cannot rescue the policy parameters. |
| `engine/` | TypeScript engine. Pure `step()`, backtest harness, bounded calibrator. |
| `config/panel_quarterly.json` | Merged quarterly panel, 134 quarters, 34 series. Estimation input. |
| `config/world_demand.json` | US real imports + Dallas Fed global activity index. The export block's driver. |
| `config/cpi.json` | TPSO CPI, 189 categories, **487 months 1986–2026**, headline and core, pre-chained. |
| `config/nesdc_quarterly.json` | **NESDC quarterly national accounts, 1993Q1–2026Q2.** 134 quarters, ~270 series. Primary source for the real block. |
| `config/imf_weo_thailand.json` | IMF WEO, 40 series, 1980–2031. Fiscal, debt, PPP, population, and the scoring baseline. |
| `config/parties.json` | Feb 2026 House: 500 seats, 22 parties, ideology vectors, coalition arithmetic. |
| `config/set_history.json` | SET Index monthly, Jan 2024 – Aug 2026. |
| `config/financial.json` | Household debt (BIS, 1991Q4–2025Q4), private credit, REER. |
| `config/policy_rate.json` | BOT MPC decisions, 190 meetings May 2000 – Jun 2026, with vote splits. |
| `data/` | Raw source files as downloaded. |
| `scripts/build_nesdc.py` | Rebuilds the quarterly JSON from a NESDC release. Re-run on each new quarter. |
| `scripts/build_mpc.py` | Rebuilds the policy rate history from the BOT MPC workbook. |
| `scripts/build_cpi.py` | Rebuilds CPI from the TPSO export. Handles any period range. |
| `scripts/build_panel.py` | Merges every source into the estimation panel. |
| `scripts/estimate.py`, `scripts/probe.py` | Core equations and alternative specifications. |

## Premise in one paragraph

You lead Bhumjaithai in February 2026, holding 191 of 500 seats — 60 short of a majority — and your first act is assembling a coalition. The stated target is USD 15,000 nominal GDP per capita by end-2030. The IMF baseline is 9,092. The target is 1.65× baseline and is not reachable through growth — only through a combination of real growth, sustained inflation, and a baht appreciated to roughly 24 THB/USD, which would be a catastrophe. The game is about the gap, and about whether you closed it honestly.

## Before writing any engine code

1. Rebuild the DESIGN §3.3 score bands around the achievable frontier — a good run now lands ~9,000, not 11,000.
2. More hazard events (tourism, flooding) using the calibrated magnitudes in `config/shocks.json`.
3. A minimal turn interface, so the thing can actually be played.
3. ~~Build the engine headless~~ — done, `engine/`.
4. ~~Pass the backtest~~ — partially. Nominal and investment blocks pass; imports fail. See `BACKTEST.md`.
5. Run the **FX-dominance test** (`CALIBRATION.md` §1.2). If appreciation is not self-limiting, the design does not work and needs rethinking before any UI exists.
