#!/usr/bin/env python3
"""Inline engine + app + css into one self-contained HTML file."""
import os, re
U = 'ui'
html = open(os.path.join(U,'index.html')).read()
css  = open(os.path.join(U,'style.css')).read()
eng  = open(os.path.join(U,'engine.js')).read()
app  = open(os.path.join(U,'app.js')).read()

# resolve the app's import of ./engine.js by concatenating: strip the import,
# and expose the engine's exports as locals.
# engine.js is an IIFE exposing globalThis.ENGINE; app.js already destructures it

html = html.replace('<link rel="stylesheet" href="style.css">', f'<style>\n{css}\n</style>')
html = html.replace('<script src="engine.js"></script>\n<script type="module" src="app.js"></script>',
                    f'<script>\n{eng}\n</script>\n<script type="module">\n{app}\n</script>')
# inline the campaign song as a data URI so the single file really is single
import base64
mp3 = base64.b64encode(open(os.path.join(U, 'assets', 'anthem.mp3'), 'rb').read()).decode()
html = html.replace('src="assets/anthem.mp3"', 'src="data:audio/mpeg;base64,%s"' % mp3)

out = os.path.join(U, 'thailand-2030.html')
open(out,'w').write(html)
print('%s  %.0f KB' % (out, os.path.getsize(out)/1024))
