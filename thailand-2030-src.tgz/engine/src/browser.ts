/**
 * Browser entry point. Re-implements the four fs-backed loaders against the
 * generated inline data, then re-exports the same Game class the headless
 * harnesses use — one engine, two hosts.
 */
import { DATA } from './gen/data.js';
import { step, nextPeriod } from './engine.js';
import { BASE } from './params.js';
import { formCoalition, band, type CoalitionCfg, type PoliticalState } from './politics.js';
import {
  availableCards, applyFlags, attempt, effectiveEffects, isUnlocked,
  type PolicyCatalogue, type PolicyCard, type PolicyEffects, type PolicyOption,
} from './policies.js';
import {
  scheduleFrom, due, resolve, makeRng,
  type GameEvent, type Scheduled,
} from './events.js';
import type { Params, State, Exog, Policy } from './types.js';

const cfg = DATA.coalitions as unknown as CoalitionCfg;
const cat = DATA.policies as unknown as PolicyCatalogue;
const events = DATA.events.events as unknown as GameEvent[];
const pl = DATA.playability as unknown as
  { gains: Record<string, number>; gestation: { infraQuarters: number } };

function gains(p: Params): Params {
  const g = pl.gains;
  return { ...p,
    multCapital: p.multCapital * g.fiscal, multGovCons: p.multGovCons * g.fiscal,
    multTransfer: p.multTransfer * g.fiscal, multTax: p.multTax * g.fiscal,
    isRealRate: p.isRealRate * g.monetary, invRateRealRate: p.invRateRealRate * g.monetary,
    reformToInvestment: p.reformToInvestment * g.reformToInvestment,
    reformToTfp: p.reformToTfp * g.reformToTfp,
    infraTfpBonus: p.infraTfpBonus * g.infraTfp,
    invRateCrowding: p.invRateCrowding * g.crowdingOut,
    infraGestation: pl.gestation.infraQuarters };
}

const BASELINE = { capitalSpend: 6.1, govConsumption: 16.7, transfers: 0, taxRate: 21.1 };
const n = (v: number | null | undefined, d = 0) => (v == null || Number.isNaN(v) ? d : v);

export interface Deferred { cardId: string; returnsAtQuarter: number; }
export interface LogEntry { quarter: number; kind: string; text: string; }

export class BrowserGame {
  cfg = cfg; cat = cat; events = events;
  ps: PoliticalState;
  opinion: Record<string, number>;
  flags: Set<string>;
  quarter = 0;
  params: Params;
  stance: Record<string, number> = {
    capitalSpend: 0, govConsumption: 0, transfers: 0, taxRate: 0, reformIndex: 0,
    executionBonus: 0, fdiSignal: 0, humanCapital: 0, formalisation: 0,
    savingsRate: 0, setSupport: 0, approvalBoost: 0, institutionalSupport: 0,
  };
  approval = 48;
  /** Mutable — the ceiling event genuinely raises it. */
  debtCeiling = 70;
  set = 1621.62;
  /** Mean-reverting deviation of the SET from its nominal-GDP fundamental. */
  sentiment = 0;
  scheduled: Scheduled[] = [];
  deferred: Deferred[] = [];
  firedEvents = new Set<string>();
  playedCards = new Set<string>();
  /** Actions taken this quarter. A government cannot pass its whole programme
   *  in one sitting — cabinet time, drafting capacity and floor time are all
   *  finite. Three per quarter. */
  actionsThisTurn = 0;
  readonly actionCap = 3;
  pending: GameEvent[] = [];
  log: LogEntry[] = [];
  history: State[] = [];
  setHistory: number[] = [];
  private rng: () => number;

  constructor(coalitionId: string, seed = 20260201) {
    this.ps = formCoalition(cfg, coalitionId);
    this.opinion = { ...this.ps.opinion };
    this.flags = new Set((cat._meta as any).initial_flags ?? []);
    this.rng = makeRng(seed);
    this.params = gains(BASE);
    this.seed();
  }

  private seed() {
    const P = DATA.panel, S = DATA.supply;
    const g = (c: string, i: number, d = 0) => n((P.series as any)[c]?.[i], d);
    const mk = (i: number): State => ({
      period: P.periods[i], gap: g('gap', i), rgdp: g('rgdp_sa', i),
      potential: g('rgdp_sa', i) / (1 + g('gap', i) / 100),
      capital: S.K[i], labour: S.L[i], tfp: S.TFP[i],
      potentialGrowthYoy: 2.1, infraPipeline: [], reformStock: 0,
      exportsR: g('exp_r', i), importsR: g('imp_r', i),
      invPrivR: g('gfcf_priv_r', i), invPubR: g('gfcf_pub_r', i), consR: g('cons_r', i),
      invRate: g('gfcf_priv_n', i) / g('ngdp', i) * 100,
      cpi: g('cpi', i), cpiCore: g('cpi_core', i),
      cpiYoy: g('cpi_yoy', i), cpiCoreYoy: g('cpi_core_yoy', i),
      policyRate: g('policy_rate', i, 1), realRate: g('real_rate_cpi', i),
      reer: g('reer', i, 100), hhDebt: g('hh_debt', i, 87.5),
      debtGdp: 64.7, primaryBalance: 0, riskPremium: 0,
      capitalSpend: BASELINE.capitalSpend, govConsumption: BASELINE.govConsumption,
      transfers: 0, taxRate: BASELINE.taxRate,
    });
    const last = P.periods.length - 1;
    for (let k = 3; k >= 0; k--) this.history.push(mk(last - k));
    this.setHistory = [1493.69, 1568.37, 1591.24, 1621.62];
  }

  get state(): State { return this.history[this.history.length - 1]; }
  get label(): string {
    const y = 2026 + Math.floor((this.quarter + 1) / 4);
    return `${y} Q${((this.quarter + 1) % 4) + 1}`;
  }
  get turnsLeft(): number { return 19 - this.quarter; }
  bandOf(p: string) { return band(cfg.bands, this.opinion[p]); }


  /** The House votes on CURRENT relations, not the ones you formed the coalition
   *  with. Without this sync every opinion point earned through events was
   *  invisible to every division — which made courting the opposition pointless
   *  and VAT unwinnable by construction. */

  /** Enacting a policy moves relations. A party that likes what you just did
   *  warms to you; one that does not, cools. Without this the only way to shift
   *  the House was through events, and governing in a way the opposition
   *  respects counted for nothing. Deliberately small — roughly four points at
   *  full ideological alignment — so it is a five-year accumulation, not a
   *  transaction. */
  private shiftOpinionFromPolicy(fit: Record<string, number>, scale = 4) {
    for (const [party, f] of Object.entries(fit)) {
      if (this.opinion[party] == null || party === 'Bhumjaithai') continue;
      const d = Math.round(f * scale);
      if (d) this.opinion[party] =
        Math.max(0, Math.min(100, this.opinion[party] + d));
    }
  }

  private whipState() {
    this.ps.opinion = this.opinion;
    return this.ps;
  }

  deck(): PolicyCard[] {
    return availableCards(cat, this.flags, this.quarter).filter(c =>
      !this.playedCards.has(c.id) &&
      !this.deferred.some(d => d.cardId === c.id && d.returnsAtQuarter > this.quarter));
  }

  previewVote(card: PolicyCard, opt: PolicyOption) {
    if (!opt.requiresLegislation) return null;
    return attempt(this.whipState(), card, opt.id).result;
  }

  openTurn(): GameEvent[] {
    const st = { debtGdp: this.state.debtGdp, gap: this.state.gap,
                 cpiYoy: this.state.cpiYoy, approval: this.approval,
                 debtHeadroom: this.debtCeiling - this.state.debtGdp,
                 debtOverCeiling: this.state.debtGdp - this.debtCeiling };
    const { fired, remaining } = due(events, this.scheduled, this.quarter, st,
                                     this.flags, this.rng, this.firedEvents);
    this.scheduled = remaining;
    for (const e of fired) { this.firedEvents.add(e.id); if (e.blocking) this.pending.push(e); }
    for (const d of this.deferred.filter(d => d.returnsAtQuarter === this.quarter)) {
      const c = cat.policies.find(x => x.id === d.cardId);
      if (c) this.log.push({ quarter: this.quarter, kind: 'note', text: `${c.name} returns to the desk` });
    }
    this.deferred = this.deferred.filter(d => d.returnsAtQuarter > this.quarter);
    return this.pending;
  }

  playCard(cardId: string, optionId: string) {
    if (this.actionsThisTurn >= this.actionCap) return { ok: false, msg: 'No actions left this quarter' };
    const card = this.deck().find(c => c.id === cardId);
    if (!card) return { ok: false, msg: 'not in the deck' };
    const chosen = card.options.find(o => o.id === optionId)!;
    if (!isUnlocked(chosen, this.flags)) return { ok: false, msg: chosen.lockedNote || 'Locked' };
    this.actionsThisTurn++;
    const r = attempt(this.whipState(), card, optionId);
    if (!r.passed) {
      this.log.push({ quarter: this.quarter, kind: 'fail',
        text: `${card.name} — ${r.option.label} FAILS (${r.result!.yes} yes, ${-r.result!.margin} short)` });
      return { ok: false, msg: `Defeated — ${r.result!.yes} yes, ${-r.result!.margin} short`, vote: r.result };
    }
    const opt = r.option;
    if (opt.returnsInQuarters) this.deferred.push({ cardId, returnsAtQuarter: this.quarter + opt.returnsInQuarters });
    else this.playedCards.add(cardId);
    this.flags = applyFlags(this.flags, opt);
    this.scheduled = scheduleFrom(this.scheduled, events, cardId, optionId, this.quarter);
    const discounted = opt.dependsOn && !this.flags.has(opt.dependsOn.flag);
    this.apply(effectiveEffects(opt, this.flags));
    this.shiftOpinionFromPolicy(opt.fit);
    this.log.push({ quarter: this.quarter, kind: 'card',
      text: `${card.name} — ${opt.label}` + (discounted ? ` [×${opt.dependsOn!.withoutFactor}]` : '') });
    return { ok: true, msg: r.executive ? 'Executive action' : `Passed by ${r.result!.margin}`,
             vote: r.result, discounted };
  }

  resolveEvent(eventId: string, optionId: string) {
    const i = this.pending.findIndex(e => e.id === eventId);
    if (i < 0) return;
    const e = this.pending[i];
    const opt = e.options.find(o => o.id === optionId)!;
    const res = resolve(this.opinion, this.flags, opt);
    this.opinion = res.opinion; this.flags = res.flags;
    this.apply(res.effects);
    this.syncCeiling();
    this.pending.splice(i, 1);
    this.log.push({ quarter: this.quarter, kind: 'event', text: `${e.headline} → ${opt.label}` });
  }

  /** The ceiling event sets a flag; this is what makes the flag mean something. */
  private syncCeiling() {
    this.debtCeiling = this.flags.has('debt_ceiling_raised_again') ? 85
      : this.flags.has('debt_ceiling_raised') ? 78 : 70;
    this.params = { ...this.params, debtCeiling: this.debtCeiling };
  }

  private apply(e: PolicyEffects) {
    for (const [k, v] of Object.entries(e)) this.stance[k] = (this.stance[k] ?? 0) + (v as number);
    if (e.approvalBoost) this.approval = Math.max(0, Math.min(100, this.approval + e.approvalBoost));
    if (e.institutionalSupport)
      this.opinion.Others = Math.round(
        Math.max(0, Math.min(100, this.opinion.Others + e.institutionalSupport)));
  }

  endTurn(): { ok: boolean; msg?: string; fallen?: boolean; walked?: string[] } {
    if (this.pending.length) return { ok: false, msg: 'Resolve the news first' };
    const h = this.history, s = h[h.length - 1], lag4 = h[h.length - 4];
    const simRr = h.slice(-4).reduce((a, v) => a + (v.policyRate - v.cpiYoy), 0) / 4;
    const prev = { ...h[h.length - 2], realRate: simRr } as State;
    const ramp = Math.min(1, (this.quarter + 1) / 6);
    const cap = this.ps.effects.megaprojectCap ?? 9.0;
    const stimCap = this.ps.effects.stimulusCap ?? 2.0;
    const policy: Policy = {
      policyRate: 1.0, reer: s.reer,
      capitalSpend: Math.min(cap, BASELINE.capitalSpend + this.stance.capitalSpend * ramp),
      govConsumption: BASELINE.govConsumption + this.stance.govConsumption * ramp,
      transfers: Math.min(stimCap, this.stance.transfers * ramp),
      taxRate: BASELINE.taxRate + this.stance.taxRate * ramp,
      reformIndex: Math.min(100, this.stance.reformIndex) * (this.ps.effects.reformCapacity ?? 0.7),
    };
    const exog: Exog = { worldDemandGrowth: 3.0, globalActivity: 10.0,
                         energyInflation: 1.5 + (this.rng() - 0.5) * 3, shock: 0 };
    const params: Params = { ...this.params,
      // Disbursement is a RATE, not a multiplier: 1.0 means every baht of the
      // capital budget actually gets spent in the year it was voted. Reform can
      // approach that ceiling; it cannot manufacture spending above the budget.
      executionCapital: Math.min(1.0,
        this.params.executionCapital + this.stance.executionBonus) };
    const next = step({ state: s, prev, lag4, exog, policy, params });
    this.history.push(next);

    // SET: a fundamental anchored to nominal GDP (earnings track it with a beta
    // above one), plus a sentiment deviation that DECAYS. The previous version
    // was a random walk whose drift terms never decayed, which compounded to
    // absurd levels — 3,000 by 2030 on a 1,620 start.
    const base = this.history[3];
    const nominalIdx = (next.rgdp / base.rgdp) * (next.cpi / base.cpi);
    const fundamental = 1621.62 * Math.pow(nominalIdx, 1.15);
    const shock = (next.gap - s.gap) * 1.6
                + (this.stance.fdiSignal ?? 0) * 1.2
                + (this.stance.setSupport ?? 0) * 1.5
                + (this.approval - 48) * 0.05
                + (this.rng() - 0.5) * 5.5;
    this.sentiment = this.sentiment * 0.72 + shock / 100;
    this.sentiment = Math.max(-0.45, Math.min(0.45, this.sentiment));
    this.set = Math.max(400, fundamental * (1 + this.sentiment));
    this.setHistory.push(this.set);
    this.quarter++;
    this.actionsThisTurn = 0;
    const gov = this.government();
    if (gov.fallen) return { ok: true, fallen: true, walked: gov.walked };
    return { ok: true };
  }

  headline(): number {
    const end = this.state, start = this.history[3];
    return 8056.57 * (end.rgdp / start.rgdp) * (end.cpi / start.cpi)
         * (71.62 / 71.215) * (32.88 / 34.6);
  }
  government(): { seats: number; fallen: boolean; walked: string[] } {
    const walked = this.ps.coalition.filter(p =>
      p !== 'Bhumjaithai' && this.opinion[p] < 25 && this.approval < 35);
    const seats = this.ps.coalition.reduce((a, p) =>
      a + (walked.includes(p) ? 0 : this.ps.seats[p]), 0);
    return { seats, fallen: seats < 251, walked };
  }
  coalitionSeats() { return this.government().seats; }
}

export { band, effectiveEffects, isUnlocked, nextPeriod };
export const COALITIONS = cfg;
