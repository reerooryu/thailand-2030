/**
 * The game loop. Owns turn state, which is what the previous three loose ends
 * all needed: event effects had nowhere to accumulate, deferred cards had
 * nowhere to wait, and reform dependencies had no place to be evaluated.
 *
 * One quarter is: resolve blocking events -> play cards -> accumulate the
 * fiscal stance -> step the engine.
 */
import { formCoalition, band, vote, type PoliticalState, type CoalitionCfg } from './politics.js';
import {
  availableCards, applyFlags, initialFlags, attempt, effectiveEffects, isUnlocked,
  type PolicyCatalogue, type PolicyCard, type PolicyEffects,
} from './policies.js';
import {
  scheduleFrom, due, resolve, makeRng,
  type GameEvent, type EventOption, type Scheduled,
} from './events.js';
import { step } from './engine.js';
import { BASE } from './params.js';
import { applyGains } from './playability.js';
import { loadPanel, col } from './panel.js';
import { loadCoalitions, loadPolicies, loadEvents, loadSupply, loadPlayability } from './loaders.js';
import type { Params, State, Exog, Policy } from './types.js';

const n = (v: number | null | undefined, d = 0) => (v == null || Number.isNaN(v) ? d : v);

/** Baseline fiscal stance, % of GDP, February 2026. */
const BASELINE = { capitalSpend: 6.1, govConsumption: 16.7, transfers: 0, taxRate: 21.1 };

export interface Deferred { cardId: string; returnsAtQuarter: number; }
export interface LogEntry { quarter: number; kind: 'card' | 'event' | 'blocked' | 'note'; text: string; }

export class Game {
  cfg: CoalitionCfg; cat: PolicyCatalogue; events: GameEvent[];
  ps: PoliticalState;
  opinion: Record<string, number>;
  flags: Set<string>;
  quarter = 0;
  params: Params;

  /** Cumulative policy stance, added to BASELINE. THIS is where event effects
   *  now land — previously they moved opinion and vanished. */
  stance: Required<PolicyEffects> = {
    capitalSpend: 0, transfers: 0, taxRate: 0, reformIndex: 0, executionBonus: 0,
    fdiSignal: 0, humanCapital: 0, formalisation: 0, savingsRate: 0,
    setSupport: 0, approvalBoost: 0, institutionalSupport: 0, govConsumption: 0,
  };

  approval = 48;
  /** Mutable — the ceiling event genuinely raises it. */
  debtCeiling = 70;
  scheduled: Scheduled[] = [];
  deferred: Deferred[] = [];
  firedEvents = new Set<string>();
  playedCards = new Set<string>();
  /** Actions taken this quarter. A government cannot pass its whole programme
   *  in one sitting — cabinet time, drafting capacity and floor time are all
   *  finite. Three per quarter. */
  actionsThisTurn = 0;
  readonly actionCap = 3;
  pending: GameEvent[] = [];
  log: LogEntry[] = [];
  history: State[] = [];
  private rng: () => number;

  constructor(coalitionId: string, seed = 20260201) {
    this.cfg = loadCoalitions();
    this.cat = loadPolicies();
    this.events = loadEvents();
    this.ps = formCoalition(this.cfg, coalitionId);
    this.opinion = { ...this.ps.opinion };
    this.flags = initialFlags(this.cat);
    this.rng = makeRng(seed);
    this.params = applyGains(BASE, loadPlayability());
    this.seedHistory();
  }

  private seedHistory() {
    const p = loadPanel(); const sup = loadSupply();
    const i0 = p.periods.indexOf('2026Q2');
    const g = (c: string, i: number, d = 0) => n(col(p, c)[i], d);
    const mk = (i: number): State => ({
      period: p.periods[i], gap: g('gap', i), rgdp: g('rgdp_sa', i),
      potential: g('rgdp_sa', i) / (1 + g('gap', i) / 100),
      capital: sup.K[i], labour: sup.L[i], tfp: sup.TFP[i],
      potentialGrowthYoy: 0, infraPipeline: [], reformStock: 0,
      exportsR: g('exp_r', i), importsR: g('imp_r', i),
      invPrivR: g('gfcf_priv_r', i), invPubR: g('gfcf_pub_r', i), consR: g('cons_r', i),
      invRate: g('gfcf_priv_n', i) / g('ngdp', i) * 100,
      cpi: g('cpi', i), cpiCore: g('cpi_core', i),
      cpiYoy: g('cpi_yoy', i), cpiCoreYoy: g('cpi_core_yoy', i),
      policyRate: g('policy_rate', i), realRate: g('real_rate_cpi', i),
      reer: g('reer', i), hhDebt: g('hh_debt', i, 87.5),
      debtGdp: 64.7, primaryBalance: 0, riskPremium: 0,
      capitalSpend: BASELINE.capitalSpend, govConsumption: BASELINE.govConsumption,
      transfers: 0, taxRate: BASELINE.taxRate,
    });
    for (let k = 3; k >= 0; k--) this.history.push(mk(i0 - k));
  }

  get state(): State { return this.history[this.history.length - 1]; }
  get label(): string { const y = 2026 + Math.floor((this.quarter + 1) / 4); return `${y}Q${((this.quarter + 1) % 4) + 1}`; }

  /** Cards playable now: requirements met, not already played, not deferred. */

  /** The House votes on CURRENT relations, not the ones you formed the coalition
   *  with. Without this sync every opinion point earned through events was
   *  invisible to every division — which made courting the opposition pointless
   *  and VAT unwinnable by construction. */

  /** Enacting a policy moves relations. A party that likes what you just did
   *  warms to you; one that does not, cools. Without this the only way to shift
   *  the House was through events, and governing in a way the opposition
   *  respects counted for nothing. Deliberately small — roughly four points at
   *  full ideological alignment — so it is a five-year accumulation, not a
   *  transaction. */
  private shiftOpinionFromPolicy(fit: Record<string, number>, scale = 4) {
    for (const [party, f] of Object.entries(fit)) {
      if (this.opinion[party] == null || party === 'Bhumjaithai') continue;
      const d = Math.round(f * scale);
      if (d) this.opinion[party] =
        Math.max(0, Math.min(100, this.opinion[party] + d));
    }
  }

  private whipState() {
    this.ps.opinion = this.opinion;
    return this.ps;
  }

  deck(): PolicyCard[] {
    return availableCards(this.cat, this.flags, this.quarter).filter(c =>
      !this.playedCards.has(c.id) &&
      !this.deferred.some(d => d.cardId === c.id && d.returnsAtQuarter > this.quarter));
  }

  /** Draw blocking events. The turn cannot advance while `pending` is non-empty. */
  openTurn() {
    const st = { debtGdp: this.state.debtGdp, gap: this.state.gap,
                 cpiYoy: this.state.cpiYoy, approval: this.approval,
                 debtHeadroom: this.debtCeiling - this.state.debtGdp,
                 debtOverCeiling: this.state.debtGdp - this.debtCeiling };
    const { fired, remaining } = due(this.events, this.scheduled, this.quarter, st,
                                     this.flags, this.rng, this.firedEvents);
    this.scheduled = remaining;
    for (const e of fired) { this.firedEvents.add(e.id); if (e.blocking) this.pending.push(e); }
    // deferred cards that have come due
    for (const d of this.deferred.filter(d => d.returnsAtQuarter === this.quarter)) {
      const c = this.cat.policies.find(x => x.id === d.cardId);
      if (c) this.log.push({ quarter: this.quarter, kind: 'note',
        text: `${c.name} returns to the desk` });
    }
    this.deferred = this.deferred.filter(d => d.returnsAtQuarter > this.quarter);
    return this.pending;
  }

  playCard(cardId: string, optionId: string) {
    if (this.actionsThisTurn >= this.actionCap) {
      this.log.push({ quarter: this.quarter, kind: 'blocked', text: `no actions left this quarter` });
      return false;
    }
    const card = this.deck().find(c => c.id === cardId);
    if (!card) { this.log.push({ quarter: this.quarter, kind: 'blocked', text: `${cardId} not in the deck` }); return false; }
    const chosen = card.options.find(o => o.id === optionId);
    if (chosen && !isUnlocked(chosen, this.flags)) {
      this.log.push({ quarter: this.quarter, kind: 'blocked',
        text: `${card.name} — ${chosen.label} locked (${(chosen.requiresFlags ?? []).join(', ')})` });
      return false;
    }
    this.actionsThisTurn++;
    const r = attempt(this.whipState(), card, optionId);
    if (!r.passed) {
      this.log.push({ quarter: this.quarter, kind: 'card',
        text: `FAILS  ${card.name} — ${r.option.label} (${r.result!.yes} yes, ${-r.result!.margin} short)` });
      return false;
    }
    const opt = r.option;
    // deferral: the card comes back rather than being consumed
    if (opt.returnsInQuarters) {
      this.deferred.push({ cardId, returnsAtQuarter: this.quarter + opt.returnsInQuarters });
    } else {
      this.playedCards.add(cardId);
    }
    this.flags = applyFlags(this.flags, opt);
    this.scheduled = scheduleFrom(this.scheduled, this.events, cardId, optionId, this.quarter);

    const eff = effectiveEffects(opt, this.flags);
    const discounted = opt.dependsOn && !this.flags.has(opt.dependsOn.flag);
    this.applyEffects(eff);
    this.shiftOpinionFromPolicy(opt.fit);
    const how = r.executive ? 'executive' : `${r.result!.yes} yes, +${r.result!.margin}`;
    this.log.push({ quarter: this.quarter, kind: 'card',
      text: `ENACTED ${card.name} — ${opt.label} (${how})` +
            (discounted ? `  [x${opt.dependsOn!.withoutFactor} — ${opt.dependsOn!.flag} not set]` : '') +
            (opt.returnsInQuarters ? `  [returns ${this.quarter + opt.returnsInQuarters - this.quarter}q]` : '') });
    return true;
  }

  resolveEvent(eventId: string, optionId: string) {
    const i = this.pending.findIndex(e => e.id === eventId);
    if (i < 0) throw new Error(`no pending event ${eventId}`);
    const e = this.pending[i];
    const opt = e.options.find(o => o.id === optionId);
    if (!opt) throw new Error(`${eventId}: no option ${optionId}`);
    const res = resolve(this.opinion, this.flags, opt);
    this.opinion = res.opinion;
    this.flags = res.flags;
    this.applyEffects(res.effects);        // <- event effects now reach the engine
    this.syncCeiling();
    this.pending.splice(i, 1);
    this.log.push({ quarter: this.quarter, kind: 'event', text: `${e.headline} -> ${opt.label}` });
  }

  /** The ceiling event sets a flag; this is what makes the flag mean something. */
  private syncCeiling() {
    this.debtCeiling = this.flags.has('debt_ceiling_raised_again') ? 85
      : this.flags.has('debt_ceiling_raised') ? 78 : 70;
    this.params = { ...this.params, debtCeiling: this.debtCeiling };
  }

  private applyEffects(e: PolicyEffects) {
    for (const [k, v] of Object.entries(e)) {
      (this.stance as Record<string, number>)[k] =
        ((this.stance as Record<string, number>)[k] ?? 0) + (v as number);
    }
    if (e.approvalBoost) this.approval = Math.max(0, Math.min(100, this.approval + e.approvalBoost));
    if (e.institutionalSupport) {
      this.opinion.Others = Math.round(
        Math.max(0, Math.min(100, this.opinion.Others + e.institutionalSupport)));
    }
  }

  /** Advance one quarter. Throws if a blocking event is unresolved. */
  endTurn(exog: Exog) {
    if (this.pending.length) {
      throw new Error(`turn blocked: ${this.pending.map(e => e.id).join(', ')} unresolved`);
    }
    const h = this.history;
    const s = h[h.length - 1];
    const lag4 = h[h.length - 4];
    const simRr = h.slice(-4).reduce((a, v) => a + (v.policyRate - v.cpiYoy), 0) / 4;
    const prev = { ...h[h.length - 2], realRate: simRr } as State;

    const ramp = Math.min(1, (this.quarter + 1) / 6);
    const cap = this.ps.effects.megaprojectCap ?? 9.0;
    const stimCap = this.ps.effects.stimulusCap ?? 2.0;
    const policy: Policy = {
      policyRate: 1.0, reer: s.reer,
      capitalSpend: Math.min(cap, BASELINE.capitalSpend + this.stance.capitalSpend * ramp),
      govConsumption: BASELINE.govConsumption + (this.stance.govConsumption ?? 0) * ramp,
      transfers: Math.min(stimCap, this.stance.transfers * ramp),
      taxRate: BASELINE.taxRate + this.stance.taxRate * ramp,
      reformIndex: Math.min(100, this.stance.reformIndex) * (this.ps.effects.reformCapacity ?? 0.7),
    };
    const params: Params = { ...this.params,
      // Disbursement is a RATE, not a multiplier: 1.0 means every baht of the
      // capital budget actually gets spent in the year it was voted. Reform can
      // approach that ceiling; it cannot manufacture spending above the budget.
      executionCapital: Math.min(1.0,
        this.params.executionCapital + this.stance.executionBonus) };

    this.history.push(step({ state: s, prev, lag4, exog, policy, params }));
    this.quarter++;
    this.actionsThisTurn = 0;
    return this.state;
  }

  /** Has the government fallen? A coalition partner walks when it is both
   *  hostile toward you and the government is unpopular — the two conditions
   *  together, not either alone. */
  government(): { seats: number; fallen: boolean; walked: string[] } {
    const walked = this.ps.coalition.filter(p =>
      p !== 'Bhumjaithai' && this.opinion[p] < 25 && this.approval < 35);
    const seats = this.ps.coalition.reduce((a, p) =>
      a + (walked.includes(p) ? 0 : this.ps.seats[p]), 0);
    return { seats, fallen: seats < 251, walked };
  }

  score() {
    const end = this.state, start = this.history[3];
    const headline = 8056.57 * (end.rgdp / start.rgdp) * (end.cpi / start.cpi)
                   * (71.62 / 71.215) * (32.88 / 34.6);
    return {
      headline, legacy: end.potentialGrowthYoy, debtGdp: end.debtGdp,
      invRate: end.invRate, approval: this.approval,
      opinion: this.opinion,
      lostConfidence: this.government().fallen,
    };
  }
  coalitionSeats() { return this.government().seats; }
  bandOf(party: string) { return band(this.cfg.bands, this.opinion[party]); }
}
