/**
 * Optimiser: search the policy space for the best obtainable term.
 *
 * The engine is deterministic given (coalition, seed, card script, event
 * choices), so a candidate line can be evaluated by replaying the whole game
 * from 2026Q2. That is what makes search possible at all — there is no state
 * to clone, only a script to re-run.
 *
 * Method: greedy with rollout. At each decision point every legal choice is
 * tried, the game is played out to December 2030 taking no further discretionary
 * action, and the choice with the best terminal score is kept. Two refinement
 * passes then re-open each committed decision against the finished line, which
 * is what catches ordering effects — VAT before the Negative Income Tax, the
 * semiconductor board before the initiative.
 *
 * This is a local search. It finds a strong line, not a proven optimum: greedy
 * rollout is blind to a move that is bad now and good only in combination with
 * a move three years out. Where that matters, the refinement passes are the
 * partial fix and the residual gap is honest.
 *
 * Usage:  npx tsx src/optimise.ts [objective] [coalition]
 *   objective: legacy | headline | balanced   (default balanced)
 */
import { Game } from './game.js';
import type { Exog } from './types.js';
import { loadCoalitions } from './loaders.js';

const EXOG: Exog = { worldDemandGrowth: 3.0, globalActivity: 10.0, energyInflation: 1.5, shock: 0 };
const QUARTERS = 19;
const SEED = 20260201;

interface Move { q: number; card: string; option: string; }
type EventChoices = Record<string, string>;

interface Outcome {
  headline: number; legacy: number; debtGdp: number; invRate: number;
  approval: number; lostConfidence: boolean; ceiling: number; score: number;
  moves: Move[]; events: EventChoices;
}

type Objective = 'legacy' | 'headline' | 'balanced';

/** What "best" means. Debt above the ceiling you actually legislated is a real
 *  failure, not a rounding cost, so it is priced steeply rather than banned —
 *  a line that breaches by a little to buy a lot of potential growth should
 *  still be findable. */
function scoreOf(s: any, ceiling: number, obj: Objective): number {
  if (s.lostConfidence) return -1e6;
  const breach = Math.max(0, s.debtGdp - ceiling);
  const penalty = breach * breach * 0.35;
  if (obj === 'headline') return s.headline / 1000 - penalty;
  if (obj === 'legacy') return s.legacy * 10 - penalty;
  return s.legacy * 6 + s.headline / 400 + s.invRate * 0.5 + s.approval * 0.04 - penalty;
}

/** Replay a full term from a script. Any illegal move is simply skipped, so a
 *  script that became invalid under a different line degrades instead of
 *  throwing. */
function play(coalition: string, moves: Move[], events: EventChoices, obj: Objective): Outcome {
  const g = new Game(coalition, SEED);
  for (let q = 0; q < QUARTERS; q++) {
    for (const e of g.openTurn().slice()) {
      const legal = e.options.filter((o: any) => !o.unavailable);
      const want = events[e.id];
      const pick = legal.find((o: any) => o.id === want) ?? legal[0];
      g.resolveEvent(e.id, pick.id);
    }
    for (const m of moves.filter(m => m.q === q)) {
      try { g.playCard(m.card, m.option); } catch { /* not in the deck this line */ }
    }
    g.endTurn(EXOG);
  }
  const s: any = g.score();
  return { ...s, ceiling: g.debtCeiling, score: scoreOf(s, g.debtCeiling, obj), moves, events };
}

/** Every (card, option) legally playable at quarter q under a given line. */
function optionsAt(coalition: string, moves: Move[], events: EventChoices, q: number) {
  const g = new Game(coalition, SEED);
  for (let i = 0; i < q; i++) {
    for (const e of g.openTurn().slice()) {
      const legal = e.options.filter((o: any) => !o.unavailable);
      const pick = legal.find((o: any) => o.id === events[e.id]) ?? legal[0];
      g.resolveEvent(e.id, pick.id);
    }
    for (const m of moves.filter(m => m.q === i)) { try { g.playCard(m.card, m.option); } catch {} }
    g.endTurn(EXOG);
  }
  const pending = g.openTurn();
  const out: { card: string; option: string }[] = [];
  for (const c of g.deck() as any[]) {
    for (const o of c.options) {
      if (o.unavailable) continue;
      if ((o.requiresFlags ?? []).some((f: string) => !g.flags.has(f))) continue;
      out.push({ card: c.id, option: o.id });
    }
  }
  return { options: out, pending, cap: g.actionCap };
}

/** Every event decision this line will actually face, with its legal options. */
function eventMenu(coalition: string, moves: Move[], events: EventChoices) {
  const g = new Game(coalition, SEED);
  const menu: { id: string; options: string[] }[] = [];
  for (let q = 0; q < QUARTERS; q++) {
    for (const e of g.openTurn().slice()) {
      const legal = e.options.filter((o: any) => !o.unavailable);
      menu.push({ id: e.id, options: legal.map((o: any) => o.id) });
      const pick = legal.find((o: any) => o.id === events[e.id]) ?? legal[0];
      g.resolveEvent(e.id, pick.id);
    }
    for (const m of moves.filter(m => m.q === q)) { try { g.playCard(m.card, m.option); } catch {} }
    g.endTurn(EXOG);
  }
  return menu;
}

function optimise(coalition: string, obj: Objective) {
  let moves: Move[] = [];
  let events: EventChoices = {};
  let best = play(coalition, moves, events, obj);
  let evals = 1;

  // pass 1 — fill the calendar greedily, quarter by quarter
  for (let q = 0; q < QUARTERS; q++) {
    const { cap } = optionsAt(coalition, moves, events, q);
    for (let slot = 0; slot < cap; slot++) {
      const { options } = optionsAt(coalition, moves, events, q);
      const used = new Set(moves.map(m => m.card));
      let bestMove: Move | null = null;
      for (const o of options) {
        if (used.has(o.card)) continue;
        const trial = [...moves, { q, card: o.card, option: o.option }];
        const r = play(coalition, trial, events, obj); evals++;
        if (r.score > best.score + 1e-9) { best = r; bestMove = { q, card: o.card, option: o.option }; }
      }
      if (!bestMove) break;
      moves = [...moves, bestMove];
    }
  }

  // pass 2 — the event decisions, against the finished card line
  for (let round = 0; round < 2; round++) {
    for (const e of eventMenu(coalition, moves, events)) {
      for (const oid of e.options) {
        if (events[e.id] === oid) continue;
        const trial = { ...events, [e.id]: oid };
        const r = play(coalition, moves, trial, obj); evals++;
        if (r.score > best.score + 1e-9) { best = r; events = trial; }
      }
    }
    // pass 3 — re-open every committed card decision now that events are set
    for (const m of [...moves]) {
      const others = moves.filter(x => x !== m);
      for (const qq of [m.q, Math.max(0, m.q - 1), m.q + 1]) {
        const { options } = optionsAt(coalition, others, events, qq);
        for (const o of options.filter(o => o.card === m.card)) {
          if (o.option === m.option && qq === m.q) continue;
          const trial = [...others, { q: qq, card: o.card, option: o.option }];
          const r = play(coalition, trial, events, obj); evals++;
          if (r.score > best.score + 1e-9) { best = r; moves = trial; }
        }
      }
      // and try dropping it entirely — an action not taken is an action available
      const r = play(coalition, others, events, obj); evals++;
      if (r.score > best.score + 1e-9) { best = r; moves = others; }
    }
  }
  return { best, moves, events, evals };
}

const objective = (process.argv[2] as Objective) || 'balanced';
const only = process.argv[3];
const cfg: any = loadCoalitions();
const coalitions = (cfg.options as any[]).filter(o => o.available && (!only || o.id === only));

console.log(`\nOBJECTIVE: ${objective}\n`);
for (const c of coalitions) {
  const t0 = Date.now();
  const { best, moves, events, evals } = optimise(c.id, objective);
  const secs = ((Date.now() - t0) / 1000).toFixed(0);
  console.log(`${'='.repeat(70)}\n${c.name}   (${evals} full terms simulated, ${secs}s)\n${'='.repeat(70)}`);
  console.log(`  headline ${best.headline.toFixed(0)}  legacy ${best.legacy.toFixed(2)}%  ` +
              `debt ${best.debtGdp.toFixed(1)}% / ceiling ${best.ceiling}  ` +
              `inv ${best.invRate.toFixed(1)}%  approval ${best.approval}`);
  console.log('  line:');
  for (const m of [...moves].sort((a, b) => a.q - b.q))
    console.log(`    Q${m.q + 1}  ${m.card} — ${m.option}`);
  console.log('  events: ' + Object.entries(events).map(([k, v]) => `${k}=${v}`).join(', '));
}
